import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Cliente } from '../Cliente';
import { ClienteService } from '../cliente.service';

@Component({
  selector: 'app-editar-cliente',
  templateUrl: './editar-cliente.component.html',
  styles: [
  ]
})
export class EditarClienteComponent implements OnInit {

  constructor(private ruta:ActivatedRoute, private servicio:ClienteService) { }

  ngOnInit(): void {

  }

 nuevo = new Cliente();

 agregar():void{
  this.ruta.params.subscribe(
    (params:Params) => { this.nuevo = params.cliente }
  );
  console.log(this.nuevo)
  let listaClientes:Cliente[] =this.servicio.getClientes();
  if(this.nuevo.telefono != 0){
    listaClientes.push(this.nuevo);
    listaClientes.forEach(cliente => {
      if(cliente.telefono == this.nuevo.telefono){
        cliente = this.nuevo;
      }
    });
  }
  this.servicio.guardarClientes( listaClientes);
  this.nuevo = new Cliente();
 }

}
